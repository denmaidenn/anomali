@extends('layout.main')

@section('content')


<div class="content-wrapper">
    @include('layout.pelatihan')
</div>



@endsection
