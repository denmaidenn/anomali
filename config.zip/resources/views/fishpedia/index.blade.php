@extends('layout.main')

@section('content')

<div class="content-wrapper">
    @include('layout.fishpedia')
</div>

@endsection
