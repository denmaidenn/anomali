@extends('layout.main')

@section('content')
        
<div class="content-wrapper">
    @include('layout.user')
</div>
        
@endsection
