<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
          <h3 class="page-heading mb-4">Forms</h3>
          <div class="row mb-2">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title mb-4">Edit User Data</h5>
                  <form class="forms-sample" method="POST" action="<?php echo e(route('user.update', $mahasiswa->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> <!-- Menggunakan PUT untuk update data -->

                    <div class="form-group">
                      <label for="exampleInputName1">Nama</label>
                      <input name="name" type="text" class="form-control p-input" id="exampleInputName1" placeholder="Nama" value="<?php echo e(old('name', $mahasiswa->name)); ?>" required>
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"> <?php echo e($message); ?>></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Email address</label>
                      <input name="email" type="email" class="form-control p-input" id="exampleInputEmail1" placeholder="Enter email" value="<?php echo e(old('email', $mahasiswa->email)); ?>" required>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputProdi1">Prodi</label>
                      <input name="prodi" type="text" class="form-control p-input" id="exampleInputProdi1" placeholder="Prodi" value="<?php echo e(old('prodi', $mahasiswa->prodi)); ?>" required>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputKelas1">Kelas</label>
                      <input name="kelas" type="text" class="form-control p-input" id="exampleInputKelas1" placeholder="Kelas" value="<?php echo e(old('kelas', $mahasiswa->kelas)); ?>" required>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputJk1">Jenis Kelamin</label>
                      <div class="form-radio">
                        <label>
                          <input name="jenis_kelamin" value="Laki-laki" type="radio" <?php echo e($mahasiswa->jenis_kelamin == 'Laki-laki' ? 'checked' : ''); ?> required>
                          Laki-laki
                        </label>
                      </div>
                      <div class="form-radio">
                        <label>
                          <input name="jenis_kelamin" value="Perempuan" type="radio" <?php echo e($mahasiswa->jenis_kelamin == 'Perempuan' ? 'checked' : ''); ?> required>
                          Perempuan
                        </label>
                      </div>
                    </div>

                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">Update</button>
                      <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/user/manage.blade.php ENDPATH**/ ?>