

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detail Pelatihan</h1>
    <p><strong>ID:</strong> <?php echo e($pelatihan->id); ?></p>
    <p><strong>Deskripsi:</strong> <?php echo e($pelatihan->deskripsi_pelatihan); ?></p>
    <p><strong>Harga:</strong> <?php echo e($pelatihan->harga); ?></p>
    <p><strong>Video:</strong> <?php echo e($pelatihan->video_pelatihan); ?></p>

    <a href="<?php echo e(route('pelatihan.index')); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/pelatihan/show.blade.php ENDPATH**/ ?>