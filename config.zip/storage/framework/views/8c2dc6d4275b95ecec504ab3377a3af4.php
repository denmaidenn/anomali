<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h3 class="page-heading mb-4" style="font-weight: Bold">Dashboard</h3>

    <?php if(session('success_login')): ?>
      <div class="alert alert-success">
        <?php echo e(session('success_login')); ?>

      </div>
    <?php endif; ?>
    <?php if(session('error_login')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('error_login')); ?>

      </div>
    <?php endif; ?>


          <!-- User Data Table -->
          <?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- Fishpedia Table -->
          <?php echo $__env->make('layout.fishpedia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- Pelatihan Table -->
          <?php echo $__env->make('layout.pelatihan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- Fishmart Table -->
          <?php echo $__env->make('layout.fishmart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/dashboard.blade.php ENDPATH**/ ?>