<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h3 class="page-heading mb-4" style="font-weight: Bold">Form</h3>
    <div class="row mb-2">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Form User Data</h5>
                    <form class="forms-sample" method="POST" href="/formuser">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="exampleInputUserId">ID User</label>
                            <input name="id_user" type="number" class="form-control p-input" id="exampleInputUserId" placeholder="ID User" required>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail">Email address</label>
                            <input name="email" type="email" class="form-control p-input" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter email" required>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputUsername">Username</label>
                            <input name="username" type="text" class="form-control p-input" id="exampleInputUsername" placeholder="Username" required>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword">Password</label>
                            <input name="password" type="password" class="form-control p-input" id="exampleInputPassword" placeholder="Password" required>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPhone">No. Telp</label>
                            <input name="no_telp" type="text" class="form-control p-input" id="exampleInputPhone" placeholder="No. Telp" required>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/user/form.blade.php ENDPATH**/ ?>