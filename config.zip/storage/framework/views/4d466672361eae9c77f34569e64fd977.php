
    <div class="row mb-4">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between m-2">
                        <h5 class="card-title mb-4">Fishpedia Table</h5>
                        <a href="<?php echo e(route('fishpedia.create')); ?>" class="btn btn-primary">Tambah</a>
                    </div>

                    <!-- Notifikasi sukses dan error -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table center-aligned-table">
                            <thead>
                                <tr class="text-primary">
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Nama Ilmiah</th>
                                    <th>Kategori</th>
                                    <th>Asal</th>
                                    <th>Ukuran</th>
                                    <th>Karakteristik</th>
                                    <th>Akuarium</th>
                                    <th>Suhu Ideal</th>
                                    <th>pH Air</th>
                                    <th>Salinitas</th>
                                    <th>Pencahayaan</th>
                                    <th>Manage</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $fish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fishes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($fishes->id); ?></td>
                                        <td><?php echo e($fishes->name); ?></td>
                                        <td><?php echo e($fishes->scientific_name); ?></td>
                                        <td><?php echo e($fishes->category); ?></td>
                                        <td><?php echo e($fishes->origin); ?></td>
                                        <td><?php echo e($fishes->size); ?></td>
                                        <td><?php echo e($fishes->characteristics); ?></td>
                                        <td><?php echo e($fishes->aquarium_size); ?></td>
                                        <td><?php echo e($fishes->temperature); ?></td>
                                        <td><?php echo e($fishes->ph); ?></td>
                                        <td><?php echo e($fishes->salinity); ?></td>
                                        <td><?php echo e($fishes->lighting); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('fishpedia.edit', $fishes->id)); ?>" class="btn btn-primary btn-sm">Manage</a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('fishpedia.delete', $fishes->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin menghapus data ini?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/layout/fishpedia.blade.php ENDPATH**/ ?>