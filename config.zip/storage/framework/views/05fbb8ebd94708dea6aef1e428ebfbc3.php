<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <?php echo $__env->make('layout.fishpedia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/fishpedia/index.blade.php ENDPATH**/ ?>