<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h3 class="page-heading mb-4" style="font-weight: Bold">Edit Produk</h3>
    <div class="row mb-2">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Form Edit Produk</h5>
                    <form class="form-sample" method="POST" action="<?php echo e(route('fishmart.update', $produk->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- Menggunakan PUT untuk update data -->

                        <div class="form-group">
                            <label for="nama_produk">Nama Produk</label>
                            <input name="nama_produk" type="text" class="form-control p-input" id="nama_produk" placeholder="Nama Produk" value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>" required>
                            <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="deskripsi_produk">Deskripsi Produk</label>
                            <textarea name="deskripsi_produk" class="form-control p-input" id="deskripsi_produk" placeholder="Deskripsi Produk" rows="3"><?php echo e(old('deskripsi_produk', $produk->deskripsi_produk)); ?></textarea>
                            <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input name="stok" type="number" class="form-control p-input" id="stok" placeholder="Jumlah Stok" value="<?php echo e(old('stok', $produk->stok)); ?>" required>
                            <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input name="harga" type="number" step="0.01" class="form-control p-input" id="harga" placeholder="Harga Produk" value="<?php echo e(old('harga', $produk->harga)); ?>" required>
                            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="gambar_produk">Gambar Produk</label>
                            <input name="gambar_produk" type="file" class="form-control-file" id="gambar_produk">
                            <small class="form-text text-muted">Unggah gambar jika ingin mengganti gambar yang sudah ada.</small>
                            <?php if($produk->gambar_produk): ?>
                                <div class="mt-2">
                                    <img src="<?php echo e(asset('storage/' . $produk->gambar_produk)); ?>" alt="Gambar Produk" width="100">
                                </div>
                            <?php endif; ?>
                            <?php $__errorArgs = ['gambar_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('fishmart.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/fishmart/edit.blade.php ENDPATH**/ ?>