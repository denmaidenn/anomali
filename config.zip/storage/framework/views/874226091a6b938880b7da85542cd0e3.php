<div class="row mb-4">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between m-2">
                            <h5 class="card-title mb-4">Tabel Pelatihan</h5>
                            <a href="<?php echo e(route('pelatihan.create')); ?>" class="btn btn-primary">Tambah</a>
                        </div>

                        <!-- Notifikasi sukses dan error -->
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="table-responsive">
                            <table class="table center-aligned-table">
                                <thead>
                                    <tr class="text-primary">
                                        <th>No</th>
                                        <th>User ID</th>
                                        <th>Video Pelatihan</th>
                                        <th>Deskripsi</th>
                                        <th>Harga</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pelatihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelatihans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pelatihans->id); ?></td>
                                            <td><?php echo e($pelatihans->id_user); ?></td>
                                            <td><?php echo e($pelatihans->video_pelatihan); ?></td>
                                            <td><?php echo e($pelatihans->deskripsi); ?></td>
                                            <td>Rp <?php echo e(number_format($pelatihans->harga, 2)); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('pelatihan.edit', $pelatihans->id)); ?>" class="btn btn-primary btn-sm">Manage</a>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('pelatihan.destroy', $pelatihans->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin menghapus data ini?');" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
          </div><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/layout/pelatihan.blade.php ENDPATH**/ ?>