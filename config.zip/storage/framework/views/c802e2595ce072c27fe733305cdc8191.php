<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h3 class="page-heading mb-4" style="font-weight: Bold">Edit Fish Data</h3>

    <div class="row mb-2">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('fishpedia.update', $fish->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Menampilkan pesan kesalahan jika ada -->
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <!-- Nama -->
                        <div class="form-group">
                            <label for="name">Nama Ikan</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $fish->name)); ?>" required>
                        </div>

                        <!-- Nama Ilmiah -->
                        <div class="form-group">
                            <label for="scientific_name">Nama Ilmiah</label>
                            <input type="text" name="scientific_name" class="form-control" value="<?php echo e(old('scientific_name', $fish->scientific_name)); ?>" required>
                        </div>

                        <!-- Kategori -->
                        <div class="form-group">
                            <label for="category">Kategori</label>
                            <input type="text" name="category" class="form-control" value="<?php echo e(old('category', $fish->category)); ?>" required>
                        </div>

                        <!-- Asal -->
                        <div class="form-group">
                            <label for="origin">Asal</label>
                            <input type="text" name="origin" class="form-control" value="<?php echo e(old('origin', $fish->origin)); ?>" required>
                        </div>

                        <!-- Ukuran -->
                        <div class="form-group">
                            <label for="size">Ukuran (cm)</label>
                            <input type="text" name="size" class="form-control" value="<?php echo e(old('size', $fish->size)); ?>" required>
                        </div>

                        <!-- Karakteristik -->
                        <div class="form-group">
                            <label for="characteristics">Karakteristik</label>
                            <input type="text" name="characteristics" class="form-control" value="<?php echo e(old('characteristics', $fish->characteristics)); ?>" required>
                        </div>

                        <!-- Akuarium -->
                        <div class="form-group">
                            <label for="aquarium_size">Ukuran Akuarium</label>
                            <input type="text" name="aquarium_size" class="form-control" value="<?php echo e(old('aquarium_size', $fish->aquarium_size)); ?>" required>
                        </div>

                        <!-- Suhu Ideal -->
                        <div class="form-group">
                            <label for="temperature">Suhu Ideal (°C)</label>
                            <input type="text" name="temperature" class="form-control" value="<?php echo e(old('temperature', $fish->temperature)); ?>" required>
                        </div>

                        <!-- pH Air -->
                        <div class="form-group">
                            <label for="ph">pH Air</label>
                            <input type="text" name="ph" class="form-control" value="<?php echo e(old('ph', $fish->ph)); ?>" required>
                        </div>

                        <!-- Salinitas -->
                        <div class="form-group">
                            <label for="salinity">Salinitas</label>
                            <input type="text" name="salinity" class="form-control" value="<?php echo e(old('salinity', $fish->salinity)); ?>" required>
                        </div>

                        <!-- Pencahayaan -->
                        <div class="form-group">
                            <label for="lighting">Pencahayaan</label>
                            <input type="text" name="lighting" class="form-control" value="<?php echo e(old('lighting', $fish->lighting)); ?>" required>
                        </div>

                        <!-- Tombol Submit -->
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Update Fish Data</button>
                            <a href="<?php echo e(route('fishpedia.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/fishpedia/edit.blade.php ENDPATH**/ ?>