<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h3 class="page-heading mb-4" style="font-weight: bold">Pelatihan</h3>
    <div class="row mb-2">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Form Tambah Data Pelatihan</h5>

                    <!-- Notifikasi sukses dan error -->
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                      <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                      </div>
                    <?php endif; ?>

                    <!-- Form untuk menambah pelatihan baru -->
                    <form id="pelatihan-form" action="<?php echo e(route('pelatihan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <!-- Dropdown untuk memilih User ID -->
                        <div class="form-group">
                            <label for="id_user">User</label>
                            <select class="form-control" id="id_user" name="id_user" required>
                                <option value="" disabled selected>Pilih User</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="video_pelatihan">Video Pelatihan</label>
                            <input type="text" class="form-control" id="video_pelatihan" name="video_pelatihan" placeholder="Masukkan URL video pelatihan" required>
                        </div>

                        <div class="form-group">
                            <label for="deskripsi">Deskripsi Pelatihan</label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" placeholder="Masukkan deskripsi pelatihan" required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" placeholder="Masukkan harga pelatihan" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('pelatihan.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/pelatihan/create.blade.php ENDPATH**/ ?>