<div class="row mb-2">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex justify-content-between m-2">
                    <h5 class="card-title mb-4">User Data Table</h5>
                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary ">Tambah</a>
                  </div>
                  <div class="table-responsive">

                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                      <div class="alert alert-danger">
                      <?php echo e(session('error')); ?>

                      </div>
                    <?php endif; ?>
                    <table class="table center-aligned-table">
                      <thead>
                        <tr class="text-primary">
                          <th> No</th>
                          <th>Nama</th>
                          <th> Email</th>
                          <th> Prodi</th>
                          <th> Kelas</th>
                          <th> Jenis Kelamin </th>
                          <th></th>
                          <th></th>

                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="">
                          <td><?php echo e($mahasiswa->id); ?></td>
                          <td><?php echo e($mahasiswa-> name); ?></td>
                          <td><?php echo e($mahasiswa-> email); ?></td>
                          <td><?php echo e($mahasiswa-> prodi); ?></td>
                          <td><?php echo e($mahasiswa-> kelas); ?></td>
                          <td><?php echo e($mahasiswa-> jenis_kelamin); ?></td>
                          <div>
                            <td>
                              <a href="<?php echo e(route('user.edit', $mahasiswa -> id)); ?>"  class="btn btn-primary btn-sm">Manage</a>
                            </td>
                            <td>

                              <form action="<?php echo e(route('user.delete', $mahasiswa -> id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin menghapus data ini?');" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                  <button  type="submit" class="btn btn-danger btn-sm">Remove</button>


                              </form>
                            </td>
                          </div>

                        </tr>


                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/layout/user.blade.php ENDPATH**/ ?>