<footer class="footer">
          <div class="container-fluid clearfix">
            <span class="float-right">
                <a href="#">Star Admin</a> &copy; 2017
            </span>
          </div>
        </footer><?php /**PATH C:\Users\sclyn\OneDrive\Documents\GitHub\anomali\resources\views/layout/footer.blade.php ENDPATH**/ ?>